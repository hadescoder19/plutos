#include <iostream>

int main() {
  std::cout << "os still in the beta fase. still under development.\n";
}